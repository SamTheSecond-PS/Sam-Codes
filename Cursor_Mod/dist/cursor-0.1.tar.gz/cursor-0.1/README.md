# Cursor Module

Its a lightweight text navigation and editor which allows the
user to navigate through alot of text instead of manually writing loops.

## Installation

```bash
pip install cursor_mod
```

## Usage

```python
import cursor as cs

text = "Hello, World!"
c = cs.Cursor(text)

# Move to comma, select and replace
c.mov_until_char(",").select(c.pos).replace_text("!!!")

# Insert tab or newline
c.tab().enter()

# Delete a selection
c.select(5).del_text()

print(c.text)
```

## Have a nice code!
