class Cursor:
    def __init__(self, text):
        self.text = text
        self.pos = 0
        self.selection = None
        self._last_pos = 0

    def mov_until_char(self, char):
        self._last_pos = self.pos  
        found = self.text.find(char, self.pos)
        if found == -1:
            raise ValueError(f"Character '{char}' not found")
        self.pos = found
        return self

    def __insert_char(self, char):
        before = self.text[:self.pos]
        after = self.text[self.pos:]
        self.text = f"{before}{char}{after}"
        self.pos += 1
        return self

    
    def tab(self):
        return self.__insert_char("\t")

    def enter(self):
        return self.__insert_char("\n")

    def select(self):
        if hasattr(self, "_last_pos"):
            start = self._last_pos
        else:
            start = self.pos  
        end = self.pos
        self.selection = (min(start, end), max(start, end))
        self._last_pos = self.pos  
        return self

    
    def replace_text(self, new_text):
        if self.selection is None:
            raise ValueError("No selection to replace")
        start, end = self.selection
        before = self.text[:start]
        after = self.text[end:]
        self.text = f"{before}{new_text}{after}"
        self.pos = start + len(new_text)
        self.selection = None
        return self

    def del_text(self):
        if self.selection is None:
            raise ValueError("No selection to delete")
        start, end = self.selection
        before = self.text[:start]
        after = self.text[end:]
        self.text = f"{before}{after}"
        self.selection = None
        self.pos = start
        return self

    def mov(self, times):
        if not isinstance(times, int):
            raise TypeError(f"Expected int, got {type(times).__name__}")
        if times < 0:
            raise ValueError(f"mov only accepts positive integers, got {times}")
        if self.pos + times > len(self.text):
            raise IndexError(f"position {self.pos} + {times} out of range")
        self._last_pos = self.pos
        self.pos += times
        return self
    
    def back(self, times):
        if not isinstance(times, int):
            raise TypeError(f"Expected int, got {type(times).__name__}")
        if times < 0:
            raise ValueError(f"back only accepts positive integers to subtract, got {times}")
        if self.pos - times < 0:
            raise IndexError(f"position {self.pos} - {times} out of range")
        self._last_pos = self.pos
        self.pos -= times
        return self
    
    def back_until_char(self, char):
        self._last_pos = self.pos
        found = self.text.rfind(char, 0, self.pos)
        if found == -1:
            raise ValueError(f"Character '{char}' not found before cursor")
        self.pos = found
        return self

    @property
    def selected_text(self):
        if self.selection is None:
            return ""
        start, end = self.selection
        return self.text[start:end]


            